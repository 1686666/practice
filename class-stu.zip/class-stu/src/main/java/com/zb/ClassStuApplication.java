package com.zb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassStuApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClassStuApplication.class, args);
	}

}
